/********************************************************************************
** Form generated from reading UI file 'tachar_actividades.ui'
**
** Created by: Qt User Interface Compiler version 5.15.13
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TACHAR_ACTIVIDADES_H
#define UI_TACHAR_ACTIVIDADES_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_tachar_actividades
{
public:
    QLabel *label;
    QLabel *tachar_nombre;
    QLabel *tachar_materias;
    QTextEdit *recibir_nombre_tachar;
    QTextEdit *recibir_materia_tachar;
    QPushButton *tachar;

    void setupUi(QDialog *tachar_actividades)
    {
        if (tachar_actividades->objectName().isEmpty())
            tachar_actividades->setObjectName(QString::fromUtf8("tachar_actividades"));
        tachar_actividades->resize(654, 397);
        tachar_actividades->setStyleSheet(QString::fromUtf8("background-color: rgb(51, 209, 122);\n"
"background-color: rgb(94, 92, 100);"));
        label = new QLabel(tachar_actividades);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(210, 0, 211, 31));
        label->setStyleSheet(QString::fromUtf8("font: 700 16pt \"Ubuntu\";"));
        label->setAlignment(Qt::AlignmentFlag::AlignCenter);
        tachar_nombre = new QLabel(tachar_actividades);
        tachar_nombre->setObjectName(QString::fromUtf8("tachar_nombre"));
        tachar_nombre->setGeometry(QRect(80, 110, 121, 31));
        tachar_nombre->setStyleSheet(QString::fromUtf8("font: 500 14pt \"Ubuntu\";"));
        tachar_materias = new QLabel(tachar_actividades);
        tachar_materias->setObjectName(QString::fromUtf8("tachar_materias"));
        tachar_materias->setGeometry(QRect(80, 200, 121, 31));
        tachar_materias->setStyleSheet(QString::fromUtf8("font: 500 14pt \"Ubuntu\";"));
        recibir_nombre_tachar = new QTextEdit(tachar_actividades);
        recibir_nombre_tachar->setObjectName(QString::fromUtf8("recibir_nombre_tachar"));
        recibir_nombre_tachar->setGeometry(QRect(200, 110, 371, 41));
        recibir_materia_tachar = new QTextEdit(tachar_actividades);
        recibir_materia_tachar->setObjectName(QString::fromUtf8("recibir_materia_tachar"));
        recibir_materia_tachar->setGeometry(QRect(200, 200, 371, 41));
        tachar = new QPushButton(tachar_actividades);
        tachar->setObjectName(QString::fromUtf8("tachar"));
        tachar->setGeometry(QRect(220, 290, 211, 51));
        tachar->setStyleSheet(QString::fromUtf8("font: 500 14pt \"Ubuntu\";\n"
"background-color: rgb(119, 118, 123);"));

        retranslateUi(tachar_actividades);

        QMetaObject::connectSlotsByName(tachar_actividades);
    } // setupUi

    void retranslateUi(QDialog *tachar_actividades)
    {
        tachar_actividades->setWindowTitle(QCoreApplication::translate("tachar_actividades", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("tachar_actividades", "Tachar actividades", nullptr));
        tachar_nombre->setText(QCoreApplication::translate("tachar_actividades", "Nombre", nullptr));
        tachar_materias->setText(QCoreApplication::translate("tachar_actividades", "Materia", nullptr));
        tachar->setText(QCoreApplication::translate("tachar_actividades", "Tachar", nullptr));
    } // retranslateUi

};

namespace Ui {
    class tachar_actividades: public Ui_tachar_actividades {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TACHAR_ACTIVIDADES_H
