/********************************************************************************
** Form generated from reading UI file 'calendario.ui'
**
** Created by: Qt User Interface Compiler version 5.15.13
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CALENDARIO_H
#define UI_CALENDARIO_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCalendarWidget>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_calendario
{
public:
    QCalendarWidget *calendarWidget;
    QLabel *label;
    QPushButton *pushButton;

    void setupUi(QDialog *calendario)
    {
        if (calendario->objectName().isEmpty())
            calendario->setObjectName(QString::fromUtf8("calendario"));
        calendario->resize(657, 403);
        calendario->setStyleSheet(QString::fromUtf8("background-color: rgb(94, 92, 100);"));
        calendarWidget = new QCalendarWidget(calendario);
        calendarWidget->setObjectName(QString::fromUtf8("calendarWidget"));
        calendarWidget->setGeometry(QRect(95, 60, 461, 241));
        label = new QLabel(calendario);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(190, 0, 301, 51));
        label->setStyleSheet(QString::fromUtf8("font: 700 16pt \"Ubuntu\";"));
        label->setAlignment(Qt::AlignmentFlag::AlignCenter);
        pushButton = new QPushButton(calendario);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(220, 330, 201, 41));
        pushButton->setStyleSheet(QString::fromUtf8("font: 500 14pt \"Ubuntu\";\n"
"background-color: rgb(119, 118, 123);"));

        retranslateUi(calendario);

        QMetaObject::connectSlotsByName(calendario);
    } // setupUi

    void retranslateUi(QDialog *calendario)
    {
        calendario->setWindowTitle(QCoreApplication::translate("calendario", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("calendario", "Calendario", nullptr));
        pushButton->setText(QCoreApplication::translate("calendario", "Salir", nullptr));
    } // retranslateUi

};

namespace Ui {
    class calendario: public Ui_calendario {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CALENDARIO_H
