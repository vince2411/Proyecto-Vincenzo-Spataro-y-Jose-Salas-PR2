# Guardado de actividades en CSV (NUEVO)

Resumen breve
------------
Se agregó funcionalidad para guardar y cargar todas las actividades a/desde un archivo CSV sencillo llamado `actividades.csv`.

Qué se agregó (archivos nuevos)
--------------------------------
- `csvutils.h`  (NUEVO): declaraciones de funciones para leer/escribir CSV.
- `csvutils.cpp` (NUEVO): implementación de lectura/escritura CSV con comentarios detallados en español.
- `README.md` (este archivo) (NUEVO).

Qué se modificó
----------------
- `main.cpp` (NUEVO): ahora carga actividades desde `actividades.csv` al iniciar la aplicación usando `loadActivitiesFromCsv("actividades.csv")`.
  - Línea agregada: llamada a `loadActivitiesFromCsv` antes de crear `MainWindow`.
- `mainwindow.cpp` (NUEVO): incluye `csvutils.h` y guarda con `saveActivitiesToCsv(actividades, "actividades.csv")` en los siguientes lugares:
  - Después de agregar una actividad en `on_agregar_actividades_clicked()`.
  - Después de eliminar una actividad en `on_eliminar_actividades_clicked()`.
  - Después de tachar/actualizar una actividad en `on_tachar_actividades_clicked()`.
  - En el destructor `~MainWindow()` para asegurarse de guardar al cerrar la aplicación.

Notas sobre el CSV y formato
---------------------------
- Archivo: `actividades.csv` (se crea en el directorio de trabajo actual de la aplicación).
- Cabecera: `nombre,prioridad,materia,fecha,realizada` (la cabecera se escribe al guardar).
- Cada campo de texto se guarda entre comillas. Las comillas internas se duplican según el estándar CSV.
- El campo `realizada` se guarda como `1` (true) o `0` (false).

Detalles técnicos y diseño (por qué y cómo)
----------------------------------------
- Se creó una utilidad pequeña y sin dependencias externas (solo QT) para mantener el proyecto simple.
- Lectura: si el archivo no existe, `loadActivitiesFromCsv` devuelve un vector vacío (comportamiento sencillo y predecible).
- Escritura: `saveActivitiesToCsv` sobrescribe el archivo entero con la lista actual de actividades.
- Parsing: `csvutils.cpp` implementa un parseador básico que soporta campos entre comillas y comillas escapadas con doble comilla.

Comentarios en el código
------------------------
Todos los lugares nuevos o modificados contienen comentarios que incluyen la etiqueta `NUEVO` para que tu compañero identifique rápido qué fue agregado.

Cómo probarlo (compilación y ejecución)
-------------------------------------
Usando Qt Creator:
- Abrir el proyecto `Administrador.pro` en Qt Creator.
- Ejecutar "Run" (Compilar y Ejecutar) desde Qt Creator.

Desde terminal (Linux) con qmake + make:
```bash
cd /ruta/al/proyecto/Administrador
qmake
make
./Administrador
```

Observaciones finales
---------------------
- El CSV generado es legible y puede abrirse en Excel, LibreOffice o un editor de texto.
- Si deseas que la aplicación guarde en un path específico (por ejemplo, carpeta de usuario), puedo cambiar el comportamiento para usar `QStandardPaths` y guardar en `AppData`/`XDG` correspondiente.

Si quieres, puedo ahora:
- Añadir carga automática al cerrar/abrir repetido (ya está implementado en destructor e inicio).
- Cambiar la ruta por defecto del CSV a una carpeta del usuario.
- Añadir una opción en la UI para forzar guardar o seleccionar archivo.
