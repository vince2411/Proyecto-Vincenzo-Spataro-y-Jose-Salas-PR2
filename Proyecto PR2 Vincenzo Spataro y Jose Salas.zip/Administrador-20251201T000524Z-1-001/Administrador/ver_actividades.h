#ifndef VER_ACTIVIDADES_H
#define VER_ACTIVIDADES_H

#include <QDialog>
#include <QListWidget>
#include "tareas.h"

namespace Ui {
class ver_actividades;
}

class ver_actividades : public QDialog
{
    Q_OBJECT

public:
    explicit ver_actividades(QWidget *parent = nullptr);
    void mostrarActividades(const QVector<Actividad>& lista_actividades);
    ~ver_actividades();

private slots:
    void on_salir_clicked();

private:
    Ui::ver_actividades *ui;
};

#endif // VER_ACTIVIDADES_H
