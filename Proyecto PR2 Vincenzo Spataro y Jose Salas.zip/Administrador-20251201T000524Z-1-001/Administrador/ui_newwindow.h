/********************************************************************************
** Form generated from reading UI file 'newwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.13
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NEWWINDOW_H
#define UI_NEWWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_newwindow
{
public:
    QLabel *label;
    QLabel *nombre_label;
    QLabel *fecha_label;
    QLabel *prioridad_label;
    QPushButton *guardar_actividad;
    QTextEdit *recibir_nombre;
    QTextEdit *recibir_prioridad;
    QTextEdit *recibir_materia;
    QLabel *materia_label;
    QDateEdit *recibir_fecha;

    void setupUi(QDialog *newwindow)
    {
        if (newwindow->objectName().isEmpty())
            newwindow->setObjectName(QString::fromUtf8("newwindow"));
        newwindow->resize(554, 356);
        newwindow->setStyleSheet(QString::fromUtf8("background-color: rgb(94, 92, 100);"));
        label = new QLabel(newwindow);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(130, 0, 281, 41));
        label->setStyleSheet(QString::fromUtf8("font: 700 15pt \"Ubuntu\";"));
        label->setAlignment(Qt::AlignmentFlag::AlignCenter);
        nombre_label = new QLabel(newwindow);
        nombre_label->setObjectName(QString::fromUtf8("nombre_label"));
        nombre_label->setGeometry(QRect(40, 70, 91, 31));
        nombre_label->setStyleSheet(QString::fromUtf8("font: 500 11pt \"Ubuntu\";\n"
"font: 500 14pt \"Ubuntu\";"));
        fecha_label = new QLabel(newwindow);
        fecha_label->setObjectName(QString::fromUtf8("fecha_label"));
        fecha_label->setGeometry(QRect(40, 120, 91, 31));
        fecha_label->setStyleSheet(QString::fromUtf8("font: 500 11pt \"Ubuntu\";\n"
"font: 500 14pt \"Ubuntu\";"));
        prioridad_label = new QLabel(newwindow);
        prioridad_label->setObjectName(QString::fromUtf8("prioridad_label"));
        prioridad_label->setGeometry(QRect(30, 180, 91, 31));
        prioridad_label->setStyleSheet(QString::fromUtf8("font: 500 11pt \"Ubuntu\";\n"
"font: 500 14pt \"Ubuntu\";"));
        guardar_actividad = new QPushButton(newwindow);
        guardar_actividad->setObjectName(QString::fromUtf8("guardar_actividad"));
        guardar_actividad->setGeometry(QRect(180, 290, 191, 51));
        guardar_actividad->setStyleSheet(QString::fromUtf8("background-color: rgb(119, 118, 123);\n"
"font: 14pt \"Ubuntu\";"));
        recibir_nombre = new QTextEdit(newwindow);
        recibir_nombre->setObjectName(QString::fromUtf8("recibir_nombre"));
        recibir_nombre->setGeometry(QRect(130, 70, 361, 31));
        recibir_prioridad = new QTextEdit(newwindow);
        recibir_prioridad->setObjectName(QString::fromUtf8("recibir_prioridad"));
        recibir_prioridad->setGeometry(QRect(130, 180, 361, 31));
        recibir_materia = new QTextEdit(newwindow);
        recibir_materia->setObjectName(QString::fromUtf8("recibir_materia"));
        recibir_materia->setGeometry(QRect(130, 240, 361, 31));
        materia_label = new QLabel(newwindow);
        materia_label->setObjectName(QString::fromUtf8("materia_label"));
        materia_label->setGeometry(QRect(40, 240, 81, 31));
        materia_label->setStyleSheet(QString::fromUtf8("font: 500 11pt \"Ubuntu\";\n"
"font: 500 14pt \"Ubuntu\";"));
        recibir_fecha = new QDateEdit(newwindow);
        recibir_fecha->setObjectName(QString::fromUtf8("recibir_fecha"));
        recibir_fecha->setGeometry(QRect(130, 120, 361, 41));

        retranslateUi(newwindow);

        QMetaObject::connectSlotsByName(newwindow);
    } // setupUi

    void retranslateUi(QDialog *newwindow)
    {
        newwindow->setWindowTitle(QCoreApplication::translate("newwindow", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("newwindow", "Agregar Actividad", nullptr));
        nombre_label->setText(QCoreApplication::translate("newwindow", "Nombre: ", nullptr));
        fecha_label->setText(QCoreApplication::translate("newwindow", "Fecha:", nullptr));
        prioridad_label->setText(QCoreApplication::translate("newwindow", "Prioridad:", nullptr));
        guardar_actividad->setText(QCoreApplication::translate("newwindow", "Guardar Actividad", nullptr));
        materia_label->setText(QCoreApplication::translate("newwindow", "Materia:", nullptr));
    } // retranslateUi

};

namespace Ui {
    class newwindow: public Ui_newwindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NEWWINDOW_H
