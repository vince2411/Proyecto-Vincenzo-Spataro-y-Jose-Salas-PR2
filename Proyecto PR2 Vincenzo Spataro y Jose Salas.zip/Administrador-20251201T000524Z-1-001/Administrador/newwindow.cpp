#include "newwindow.h"
#include "ui_newwindow.h"

newwindow::newwindow(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::newwindow)
{
    ui->setupUi(this);
}

newwindow::~newwindow()
{
    delete ui;
}

Actividad newwindow::getActividad() const{
    return nueva_actividad;
}

void newwindow::on_guardar_actividad_clicked()
{
    QString nombre, prioridad, materia, fecha;
    nombre=ui->recibir_nombre->toPlainText().trimmed().toLower();
    prioridad = ui->recibir_prioridad->toPlainText().trimmed().toLower();
    fecha = ui->recibir_fecha->date().toString("dd/MM/yyyy");
    materia = ui->recibir_materia->toPlainText().trimmed().toLower();
    if (nombre.isEmpty() || prioridad.isEmpty() || fecha.isEmpty() || materia.isEmpty()) {

        return;
    }

    if (prioridad != "alta" && prioridad != "media" && prioridad != "baja") {
        return;
    }

    nueva_actividad=Actividad(nombre, prioridad, materia, fecha);
    accept();
}
