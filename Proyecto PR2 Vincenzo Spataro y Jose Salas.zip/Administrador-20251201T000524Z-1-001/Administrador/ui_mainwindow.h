/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.13
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QLabel *Titulo_principal;
    QPushButton *agregar_actividades;
    QPushButton *ver_actividades;
    QPushButton *actividades_realizadas;
    QPushButton *tachar_actividades;
    QPushButton *eliminar_actividades;
    QPushButton *calendario;
    QPushButton *salir;
    QLabel *label_2;
    QPushButton *actividades_por_realizar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(769, 479);
        MainWindow->setStyleSheet(QString::fromUtf8("background-color: rgb(94, 92, 100);"));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        Titulo_principal = new QLabel(centralwidget);
        Titulo_principal->setObjectName(QString::fromUtf8("Titulo_principal"));
        Titulo_principal->setGeometry(QRect(220, 0, 361, 41));
        Titulo_principal->setStyleSheet(QString::fromUtf8("font: 700 15pt \"Ubuntu\";"));
        Titulo_principal->setAlignment(Qt::AlignmentFlag::AlignCenter);
        agregar_actividades = new QPushButton(centralwidget);
        agregar_actividades->setObjectName(QString::fromUtf8("agregar_actividades"));
        agregar_actividades->setGeometry(QRect(40, 120, 221, 41));
        agregar_actividades->setStyleSheet(QString::fromUtf8("font: 500 14pt \"Ubuntu\";\n"
"background-color: rgb(119, 118, 123);"));
        ver_actividades = new QPushButton(centralwidget);
        ver_actividades->setObjectName(QString::fromUtf8("ver_actividades"));
        ver_actividades->setGeometry(QRect(280, 120, 221, 41));
        ver_actividades->setStyleSheet(QString::fromUtf8("font: 500 14pt \"Ubuntu\";\n"
"background-color: rgb(119, 118, 123);"));
        actividades_realizadas = new QPushButton(centralwidget);
        actividades_realizadas->setObjectName(QString::fromUtf8("actividades_realizadas"));
        actividades_realizadas->setGeometry(QRect(530, 120, 221, 41));
        actividades_realizadas->setStyleSheet(QString::fromUtf8("font: 500 14pt \"Ubuntu\";\n"
"background-color: rgb(119, 118, 123);"));
        tachar_actividades = new QPushButton(centralwidget);
        tachar_actividades->setObjectName(QString::fromUtf8("tachar_actividades"));
        tachar_actividades->setGeometry(QRect(280, 190, 221, 41));
        tachar_actividades->setStyleSheet(QString::fromUtf8("font: 500 14pt \"Ubuntu\";\n"
"background-color: rgb(119, 118, 123);"));
        eliminar_actividades = new QPushButton(centralwidget);
        eliminar_actividades->setObjectName(QString::fromUtf8("eliminar_actividades"));
        eliminar_actividades->setGeometry(QRect(40, 190, 221, 41));
        eliminar_actividades->setStyleSheet(QString::fromUtf8("font: 500 14pt \"Ubuntu\";\n"
"background-color: rgb(119, 118, 123);"));
        calendario = new QPushButton(centralwidget);
        calendario->setObjectName(QString::fromUtf8("calendario"));
        calendario->setGeometry(QRect(530, 190, 221, 41));
        calendario->setStyleSheet(QString::fromUtf8("font: 500 14pt \"Ubuntu\";\n"
"background-color: rgb(119, 118, 123);"));
        salir = new QPushButton(centralwidget);
        salir->setObjectName(QString::fromUtf8("salir"));
        salir->setGeometry(QRect(410, 260, 221, 41));
        salir->setStyleSheet(QString::fromUtf8("font: 500 14pt \"Ubuntu\";\n"
"background-color: rgb(119, 118, 123);"));
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(290, 430, 211, 21));
        label_2->setStyleSheet(QString::fromUtf8("font: italic 11pt \"Ubuntu\";"));
        label_2->setAlignment(Qt::AlignmentFlag::AlignCenter);
        actividades_por_realizar = new QPushButton(centralwidget);
        actividades_por_realizar->setObjectName(QString::fromUtf8("actividades_por_realizar"));
        actividades_por_realizar->setGeometry(QRect(160, 260, 221, 41));
        actividades_por_realizar->setStyleSheet(QString::fromUtf8("font: 500 14pt \"Ubuntu\";\n"
"background-color: rgb(119, 118, 123);"));
        MainWindow->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);
        QWidget::setTabOrder(agregar_actividades, ver_actividades);
        QWidget::setTabOrder(ver_actividades, actividades_realizadas);
        QWidget::setTabOrder(actividades_realizadas, eliminar_actividades);
        QWidget::setTabOrder(eliminar_actividades, tachar_actividades);
        QWidget::setTabOrder(tachar_actividades, calendario);
        QWidget::setTabOrder(calendario, salir);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        Titulo_principal->setText(QCoreApplication::translate("MainWindow", "ADMINISTRADOR DE ACTIVIDADES", nullptr));
        agregar_actividades->setText(QCoreApplication::translate("MainWindow", "Agregar actividades", nullptr));
        ver_actividades->setText(QCoreApplication::translate("MainWindow", "Ver actividades", nullptr));
        actividades_realizadas->setText(QCoreApplication::translate("MainWindow", "Actividades realizadas", nullptr));
        tachar_actividades->setText(QCoreApplication::translate("MainWindow", "Tachar actividades", nullptr));
        eliminar_actividades->setText(QCoreApplication::translate("MainWindow", "Eliminar actividades", nullptr));
        calendario->setText(QCoreApplication::translate("MainWindow", "Calendario", nullptr));
        salir->setText(QCoreApplication::translate("MainWindow", "Salir", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "Jose Salas y Vincenzo Spataro", nullptr));
        actividades_por_realizar->setText(QCoreApplication::translate("MainWindow", "Actividades por realizar", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
