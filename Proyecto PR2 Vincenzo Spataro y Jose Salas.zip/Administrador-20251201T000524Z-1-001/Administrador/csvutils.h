#ifndef CSVUTILS_H
#define CSVUTILS_H

#include <QVector>
#include <QString>
#include "tareas.h"


QVector<Actividad> loadActivitiesFromCsv(const QString &filePath); 
bool saveActivitiesToCsv(const QVector<Actividad> &actividades, const QString &filePath); 

#endif 
