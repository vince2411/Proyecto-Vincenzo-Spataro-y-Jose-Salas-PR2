/********************************************************************************
** Form generated from reading UI file 'actividades_realizadas.ui'
**
** Created by: Qt User Interface Compiler version 5.15.13
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ACTIVIDADES_REALIZADAS_H
#define UI_ACTIVIDADES_REALIZADAS_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_actividades_realizadas
{
public:
    QLabel *actividades_realizadas_titulo;
    QListWidget *ver_actividades_realizadas;
    QPushButton *salir_actividades_realizadas;

    void setupUi(QDialog *actividades_realizadas)
    {
        if (actividades_realizadas->objectName().isEmpty())
            actividades_realizadas->setObjectName(QString::fromUtf8("actividades_realizadas"));
        actividades_realizadas->resize(643, 401);
        actividades_realizadas->setStyleSheet(QString::fromUtf8("background-color: rgb(94, 92, 100);"));
        actividades_realizadas_titulo = new QLabel(actividades_realizadas);
        actividades_realizadas_titulo->setObjectName(QString::fromUtf8("actividades_realizadas_titulo"));
        actividades_realizadas_titulo->setGeometry(QRect(180, 0, 241, 31));
        actividades_realizadas_titulo->setStyleSheet(QString::fromUtf8("font: 700 16pt \"Ubuntu\";"));
        actividades_realizadas_titulo->setAlignment(Qt::AlignmentFlag::AlignCenter);
        ver_actividades_realizadas = new QListWidget(actividades_realizadas);
        ver_actividades_realizadas->setObjectName(QString::fromUtf8("ver_actividades_realizadas"));
        ver_actividades_realizadas->setGeometry(QRect(50, 40, 541, 271));
        salir_actividades_realizadas = new QPushButton(actividades_realizadas);
        salir_actividades_realizadas->setObjectName(QString::fromUtf8("salir_actividades_realizadas"));
        salir_actividades_realizadas->setGeometry(QRect(200, 330, 201, 51));
        salir_actividades_realizadas->setStyleSheet(QString::fromUtf8("font: 500 14pt \"Ubuntu\";\n"
"background-color: rgb(119, 118, 123);"));

        retranslateUi(actividades_realizadas);

        QMetaObject::connectSlotsByName(actividades_realizadas);
    } // setupUi

    void retranslateUi(QDialog *actividades_realizadas)
    {
        actividades_realizadas->setWindowTitle(QCoreApplication::translate("actividades_realizadas", "Dialog", nullptr));
        actividades_realizadas_titulo->setText(QCoreApplication::translate("actividades_realizadas", "Actividades realizadas", nullptr));
        salir_actividades_realizadas->setText(QCoreApplication::translate("actividades_realizadas", "Salir", nullptr));
    } // retranslateUi

};

namespace Ui {
    class actividades_realizadas: public Ui_actividades_realizadas {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ACTIVIDADES_REALIZADAS_H
