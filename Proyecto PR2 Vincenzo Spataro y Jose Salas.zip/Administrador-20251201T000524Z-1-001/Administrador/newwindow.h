#ifndef NEWWINDOW_H
#define NEWWINDOW_H
#include "tareas.h"

#include <QDialog>

namespace Ui {
class newwindow;
}

class newwindow : public QDialog
{
    Q_OBJECT

public:
    explicit newwindow(QWidget *parent = nullptr);
    ~newwindow();
    Actividad getActividad() const;

private slots:
    void on_guardar_actividad_clicked();

private:
    Ui::newwindow *ui;
    Actividad nueva_actividad;
};

#endif // NEWWINDOW_H
