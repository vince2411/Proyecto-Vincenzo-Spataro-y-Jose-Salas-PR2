#include "calendario.h"
#include "ui_calendario.h"

#include <QTextCharFormat>
#include <QBrush>
#include <QColor>
#include <QMap>

#include <QDebug>

calendario::calendario(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::calendario)
{
    ui->setupUi(this);

    
    marcarFechasDesdeCsv(); 
}
calendario::~calendario()
{
    delete ui;
}

void calendario::on_pushButton_clicked()
{
    close();
}

void calendario::marcarFechasDesdeCsv()
{
   
    QVector<Actividad> actividades = loadActivitiesFromCsv("actividades.csv");

   
    QMap<QDate, int> prioridadPorFecha; 

    for (const Actividad &a : actividades) {
        QString fechaStr = a.getFecha().trimmed();
        

     
        QDate d = QDate::fromString(fechaStr, "dd/MM/yyyy");
       
        if (!d.isValid()) {
            qWarning() << "calendario: fecha inválida en actividad, se ignora:" << fechaStr;
            continue;
        }

      
        QString p = a.getPrioridad().toLower().trimmed();
        int nivel = 1; 
        if (p == "alta") nivel = 3;
        else if (p == "media") nivel = 2;
        else nivel = 1;

   
        if (!prioridadPorFecha.contains(d) || prioridadPorFecha[d] < nivel) {
            prioridadPorFecha[d] = nivel;
        }

        if(a.getRealizada()==true){
            prioridadPorFecha.remove(d);
        }

    }
  
    
   
    for (auto it = prioridadPorFecha.constBegin(); it != prioridadPorFecha.constEnd(); ++it) {
        
        QDate fecha = it.key();
        int nivel = it.value();

        QColor color;
        if (nivel == 3) color = QColor(230, 50, 50, 160); 
        else if (nivel == 2) color = QColor(240, 200, 20, 160);
        else color = QColor(80, 180, 90, 160);

        QTextCharFormat fmt = ui->calendarWidget->dateTextFormat(fecha);
       
        fmt.setBackground(QBrush(color));
      
        QFont f = fmt.font();
        f.setBold(true);
        fmt.setFont(f);

        
        ui->calendarWidget->setDateTextFormat(fecha, fmt);
    }
}

