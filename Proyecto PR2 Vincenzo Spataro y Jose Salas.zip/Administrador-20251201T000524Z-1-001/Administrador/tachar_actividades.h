#ifndef TACHAR_ACTIVIDADES_H
#define TACHAR_ACTIVIDADES_H

#include <QDialog>
#include "tareas.h"
#include <QVector>

namespace Ui {
class tachar_actividades;
}

class tachar_actividades : public QDialog
{
    Q_OBJECT

public:
    explicit tachar_actividades(QWidget *parent = nullptr);
    ~tachar_actividades();
    QVector<Actividad> getActividades() const;
    void setActividades(QVector<Actividad> _actividades);

private slots:
    void on_tachar_clicked();

private:
    Ui::tachar_actividades *ui;
    QVector<Actividad> actividades;
};

#endif // TACHAR_ACTIVIDADES_H
