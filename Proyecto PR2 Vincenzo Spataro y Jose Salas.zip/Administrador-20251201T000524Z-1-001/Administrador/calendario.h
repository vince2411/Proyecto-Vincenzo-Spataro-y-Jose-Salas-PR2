#ifndef CALENDARIO_H
#define CALENDARIO_H

#include <QDialog>
#include <QVector>
#include "tareas.h"
#include "csvutils.h" 
namespace Ui {
class calendario;
}

class calendario : public QDialog
{
    Q_OBJECT

public:
    explicit calendario(QWidget *parent = nullptr);
    ~calendario();

private slots:
    void on_pushButton_clicked();

    void marcarFechasDesdeCsv();

private:
    Ui::calendario *ui;
};

#endif 