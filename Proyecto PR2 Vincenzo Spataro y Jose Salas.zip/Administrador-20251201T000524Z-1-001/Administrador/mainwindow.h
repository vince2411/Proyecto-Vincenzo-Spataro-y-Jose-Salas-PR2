#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QVector>
#include <QMainWindow>
#include "tareas.h"

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    QVector<Actividad> actividades;
    Q_OBJECT

public:
    MainWindow(QVector<Actividad> a, QWidget *parent = nullptr);
    ~MainWindow();
    void setActividades(QVector<Actividad> _actividades);

private slots:
    void on_agregar_actividades_clicked();

    void on_salir_clicked();

    void on_ver_actividades_clicked();

    void on_calendario_clicked();

    void on_eliminar_actividades_clicked();

    void on_tachar_actividades_clicked();

    void on_actividades_realizadas_clicked();

    void on_actividades_por_realizar_clicked();

private:
    Ui::MainWindow *ui;
};
#endif 