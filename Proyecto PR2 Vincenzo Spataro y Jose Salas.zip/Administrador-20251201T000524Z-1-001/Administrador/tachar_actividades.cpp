#include "tachar_actividades.h"
#include "ui_tachar_actividades.h"

tachar_actividades::tachar_actividades(QWidget *parent): QDialog(parent), ui(new Ui::tachar_actividades)
{
    ui->setupUi(this);
}

tachar_actividades::~tachar_actividades()
{
    delete ui;
}

void tachar_actividades::setActividades(QVector<Actividad> _actividades){
    actividades=_actividades;
}

QVector<Actividad> tachar_actividades::getActividades() const{
    return actividades;
}

void tachar_actividades::on_tachar_clicked()
{
    QString nombre_tachar, materia_tachar;
    nombre_tachar=ui->recibir_nombre_tachar->toPlainText().toLower();
    materia_tachar=ui->recibir_materia_tachar->toPlainText().toLower();
    for(int i=0; i<actividades.size(); ++i){
        if(nombre_tachar==actividades[i].getNombre() && materia_tachar==actividades[i].getMateria()){
             
            actividades[i].tachar(true);
           
            break;
        }
    }
    accept();
}
