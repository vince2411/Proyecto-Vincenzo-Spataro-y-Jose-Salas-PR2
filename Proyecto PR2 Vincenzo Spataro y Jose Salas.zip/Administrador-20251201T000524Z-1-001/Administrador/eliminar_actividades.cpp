#include "eliminar_actividades.h"
#include "ui_eliminar_actividades.h"

eliminar_actividades::eliminar_actividades(QWidget *parent): QDialog(parent), ui(new Ui::eliminar_actividades)
{
    ui->setupUi(this);
}

eliminar_actividades::~eliminar_actividades()
{
    delete ui;
}

void eliminar_actividades::setActividades(QVector<Actividad> _actividades){
    actividades=_actividades;
}

void eliminar_actividades::on_eliminar_Button_clicked()
{
    QString nombre_eliminar, materia_eliminar;
    nombre_eliminar=ui->recibir_nombre_eliminar->toPlainText().toLower();
    materia_eliminar=ui->recibir_materia_eliminar->toPlainText().toLower();
    for(int i=0; i<actividades.size(); ++i){
        if(nombre_eliminar==actividades[i].getNombre() && materia_eliminar==actividades[i].getMateria()){
            actividades.removeAt(i);
            break;
        }
    }
    accept();
}

QVector<Actividad> eliminar_actividades::getActividades() const{
    return actividades;
}
