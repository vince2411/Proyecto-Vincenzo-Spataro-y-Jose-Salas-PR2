#include "mainwindow.h"
#include "csvutils.h" 

#include <QApplication>

int main(int argc, char *argv[])
{
    
   QVector<Actividad> actividades = loadActivitiesFromCsv("actividades.csv"); 

    QApplication a(argc, argv);
    MainWindow w(actividades);
    w.show();
    return a.exec();
}
