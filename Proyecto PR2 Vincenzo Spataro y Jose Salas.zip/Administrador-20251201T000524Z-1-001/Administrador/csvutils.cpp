#include "csvutils.h"
#include <QFile>
#include <QTextStream>
#include <QDebug>




static QString escapeCsvField(const QString &field) {
    QString s = field;
    
    s.replace('"', "\"\"");
    return '"' + s + '"';
}


static QVector<QString> parseCsvLine(const QString &line) {
    QVector<QString> fields;
    QString buffer;
    bool inQuotes = false;
    int len = line.length();
    for (int i = 0; i < len; ++i) {
        QChar c = line[i];
        if (inQuotes) {
            if (c == '"') {
               
                if (i + 1 < len && line[i + 1] == '"') {
                    buffer.append('"');
                    ++i; 
                } else {
                   
                    inQuotes = false;
                }
            } else {
                buffer.append(c);
            }
        } else {
            if (c == '"') {
                inQuotes = true;
            } else if (c == ',') {
                fields.push_back(buffer);
                buffer.clear();
            } else {
                buffer.append(c);
            }
        }
    }
    fields.push_back(buffer);
    return fields;
}

bool saveActivitiesToCsv(const QVector<Actividad> &actividades, const QString &filePath) {
    QFile file(filePath);
   
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        qWarning() << "CSV: no se pudo abrir" << filePath << "para escribir";
        return false;
    }
    QTextStream out(&file);
   

   
    for (const Actividad &a : actividades) {
        QString nombre = escapeCsvField(a.getNombre());
        QString prioridad = escapeCsvField(a.getPrioridad());
        QString materia = escapeCsvField(a.getMateria());
        QString fecha = escapeCsvField(a.getFecha());
        QString realizada = a.getRealizada() ? "1" : "0";
        out << nombre << ',' << prioridad << ',' << materia << ',' << fecha << ',' << realizada << "\n";
    }
    file.close();
    return true;
}


QVector<Actividad> loadActivitiesFromCsv(const QString &filePath) {
    QVector<Actividad> result;
    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        
        qInfo() << "CSV: no se pudo abrir" << filePath << "para lectura; devolviendo lista vacía";
        return result;
    }
    QTextStream in(&file);
    
    
    while (!in.atEnd()) {
        QString line = in.readLine();
        if (line.trimmed().isEmpty()) continue; 
        QVector<QString> fields = parseCsvLine(line);
        if (fields.size() < 5) {
           
            qWarning() << "CSV: línea mal formada, se ignora:" << line;
            continue;
        }
        QString nombre = fields[0];
        QString prioridad = fields[1];
        QString materia = fields[2];
        QString fecha = fields[3];
        QString realizadaStr = fields[4].trimmed();

       
        Actividad a(nombre, prioridad, materia, fecha);
        if (realizadaStr == "1" || realizadaStr.toLower() == "true") {
            a.tachar(true); 
        }
        result.push_back(a);
    }

    file.close();
    return result;
}
