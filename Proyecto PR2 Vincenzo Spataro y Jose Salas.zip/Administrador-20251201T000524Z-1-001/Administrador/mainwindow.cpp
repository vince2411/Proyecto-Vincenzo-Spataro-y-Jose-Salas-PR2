#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "newwindow.h"
#include "ver_actividades.h"
#include "calendario.h"
#include "eliminar_actividades.h"
#include "tachar_actividades.h"
#include "actividades_realizadas.h"
#include "actividades_sin_realizar.h"
#include "csvutils.h" 

MainWindow::MainWindow(QVector<Actividad> a, QWidget *parent)
    :QMainWindow(parent),
    actividades(a)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_agregar_actividades_clicked()
{
    newwindow nueva;
    nueva.setModal(true);
    int resultado=nueva.exec();
    if(resultado==QDialog::Accepted){
        Actividad na=nueva.getActividad();
        actividades.push_back(na);
        saveActivitiesToCsv(actividades, "actividades.csv"); 
    }
}


void MainWindow::on_salir_clicked()
{
     saveActivitiesToCsv(actividades, "actividades.csv"); 
    close();
}


void MainWindow::on_ver_actividades_clicked()
{
    ver_actividades nueva;
    nueva.mostrarActividades(actividades);
    nueva.setModal(true);
    nueva.exec();
}


void MainWindow::on_calendario_clicked()
{
    calendario nueva;
    nueva.setModal(true);
    nueva.exec();
}

void MainWindow::setActividades(QVector<Actividad> _actividades){
    actividades=_actividades;
}

void MainWindow::on_eliminar_actividades_clicked()
{
    eliminar_actividades nueva;
    nueva.setActividades(actividades);
    nueva.setModal(true);
    nueva.exec();
    QVector<Actividad> nuevas=nueva.getActividades();
    setActividades(nuevas);
   
    saveActivitiesToCsv(actividades, "actividades.csv"); 


}
void MainWindow::on_tachar_actividades_clicked()
{
    tachar_actividades nueva;
    nueva.setActividades(actividades);
    nueva.setModal(true);
    nueva.exec();
    QVector<Actividad> actualizadas=nueva.getActividades();
    setActividades(actualizadas);
   
    saveActivitiesToCsv(actividades, "actividades.csv"); 
}


void MainWindow::on_actividades_realizadas_clicked()
{
    actividades_realizadas nueva;
    nueva.mostrar_actividades(actividades);
    nueva.setModal(true);
    nueva.exec();
}


void MainWindow::on_actividades_por_realizar_clicked()
{
    actividades_sin_realizar nueva;
    nueva.mostrar_actividades(actividades);
    nueva.setModal(true);
    nueva.exec();
}

