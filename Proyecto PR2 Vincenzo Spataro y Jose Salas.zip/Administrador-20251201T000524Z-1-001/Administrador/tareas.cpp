#include "tareas.h"

Actividad::Actividad() {}

Actividad::Actividad(QString n, QString p, QString m, QString f): nombre(n), prioridad(p), materia(m), fecha(f), realizada(false) {}

QString Actividad::getNombre() const{
    return nombre;
}

QString Actividad::getPrioridad() const{
    return prioridad;
}

QString Actividad::getFecha() const{
    return fecha;
}

QString Actividad::getMateria() const{
    return materia;
}

bool Actividad::getRealizada() const{
    return realizada;
}

void Actividad::tachar(bool r){
    realizada=r;
}
