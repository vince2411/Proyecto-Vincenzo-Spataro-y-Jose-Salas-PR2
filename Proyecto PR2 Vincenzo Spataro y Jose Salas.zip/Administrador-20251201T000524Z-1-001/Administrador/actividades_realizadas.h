#ifndef ACTIVIDADES_REALIZADAS_H
#define ACTIVIDADES_REALIZADAS_H
#include "tareas.h"
#include <QVector>
#include <QDialog>
#include <QString>

namespace Ui {
class actividades_realizadas;
}

class actividades_realizadas : public QDialog
{
    Q_OBJECT

public:
    explicit actividades_realizadas(QWidget *parent = nullptr);
    ~actividades_realizadas();
    void mostrar_actividades(QVector<Actividad> actividades);


private slots:
    void on_salir_actividades_realizadas_clicked();

private:
    Ui::actividades_realizadas *ui;
};

#endif 
