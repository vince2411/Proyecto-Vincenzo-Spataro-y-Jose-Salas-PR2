#ifndef TAREAS_H
#define TAREAS_H
#include <QString>

class Actividad
{
        QString nombre;
        QString prioridad;
        QString materia;
        QString fecha;
        bool realizada;
    public:
        Actividad();
        Actividad(QString n, QString p, QString materia, QString f);
        QString getNombre() const;
        QString getPrioridad() const;
        QString getFecha() const;
        QString getMateria() const;
        bool getRealizada() const;
        void tachar(bool r);
};

#endif // TAREAS_H
