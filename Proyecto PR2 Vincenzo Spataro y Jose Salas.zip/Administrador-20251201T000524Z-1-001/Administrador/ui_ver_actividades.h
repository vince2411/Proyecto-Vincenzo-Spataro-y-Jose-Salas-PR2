/********************************************************************************
** Form generated from reading UI file 'ver_actividades.ui'
**
** Created by: Qt User Interface Compiler version 5.15.13
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_VER_ACTIVIDADES_H
#define UI_VER_ACTIVIDADES_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_ver_actividades
{
public:
    QLabel *label;
    QListWidget *listWidget_actividades;
    QPushButton *salir;

    void setupUi(QDialog *ver_actividades)
    {
        if (ver_actividades->objectName().isEmpty())
            ver_actividades->setObjectName(QString::fromUtf8("ver_actividades"));
        ver_actividades->resize(657, 409);
        ver_actividades->setStyleSheet(QString::fromUtf8("background-color: rgb(51, 209, 122);\n"
"background-color: rgb(94, 92, 100);"));
        label = new QLabel(ver_actividades);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(210, 0, 241, 51));
        label->setStyleSheet(QString::fromUtf8("font: 700 11pt \"Ubuntu\";\n"
"font: 700 16pt \"Ubuntu\";\n"
"font: 700 16pt \"Ubuntu\";"));
        label->setAlignment(Qt::AlignmentFlag::AlignCenter);
        listWidget_actividades = new QListWidget(ver_actividades);
        listWidget_actividades->setObjectName(QString::fromUtf8("listWidget_actividades"));
        listWidget_actividades->setGeometry(QRect(50, 50, 551, 271));
        salir = new QPushButton(ver_actividades);
        salir->setObjectName(QString::fromUtf8("salir"));
        salir->setGeometry(QRect(220, 330, 221, 51));
        salir->setStyleSheet(QString::fromUtf8("font: 500 14pt \"Ubuntu\";\n"
"background-color: rgb(119, 118, 123);"));

        retranslateUi(ver_actividades);

        QMetaObject::connectSlotsByName(ver_actividades);
    } // setupUi

    void retranslateUi(QDialog *ver_actividades)
    {
        ver_actividades->setWindowTitle(QCoreApplication::translate("ver_actividades", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("ver_actividades", "Ver Acitividades", nullptr));
        salir->setText(QCoreApplication::translate("ver_actividades", "Salir", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ver_actividades: public Ui_ver_actividades {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_VER_ACTIVIDADES_H
