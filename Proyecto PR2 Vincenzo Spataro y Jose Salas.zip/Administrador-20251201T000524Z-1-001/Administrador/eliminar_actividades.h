#ifndef ELIMINAR_ACTIVIDADES_H
#define ELIMINAR_ACTIVIDADES_H
#include <QVector>
#include <QString>
#include <QDebug>
#include <QDialog>
#include "tareas.h"

namespace Ui {
class eliminar_actividades;
}

class eliminar_actividades : public QDialog
{
    Q_OBJECT

public:
    explicit eliminar_actividades(QWidget *parent = nullptr);
    ~eliminar_actividades();
    void setActividades(QVector<Actividad> _actividades);
    QVector<Actividad> getActividades() const;

private slots:
    void on_eliminar_Button_clicked();

private:
    Ui::eliminar_actividades *ui;
    QVector<Actividad> actividades;
};

#endif // ELIMINAR_ACTIVIDADES_H
