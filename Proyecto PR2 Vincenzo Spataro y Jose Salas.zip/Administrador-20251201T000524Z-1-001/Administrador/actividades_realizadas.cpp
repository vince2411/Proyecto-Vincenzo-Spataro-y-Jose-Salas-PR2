#include "actividades_realizadas.h"
#include "ui_actividades_realizadas.h"

actividades_realizadas::actividades_realizadas(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::actividades_realizadas)
{
    ui->setupUi(this);
}

actividades_realizadas::~actividades_realizadas()
{
    delete ui;
}

void actividades_realizadas::mostrar_actividades(QVector<Actividad> actividades){
    QVector<Actividad> realizadas;
    for(int i=0; i<actividades.size(); ++i){
        if(actividades[i].getRealizada()==true){
            realizadas.push_back(actividades[i]);
        }
    }
    ui->ver_actividades_realizadas->clear();
    for(int i=0; i<realizadas.size(); ++i){
        QString textoActividad = QString("Nombre: %1 | Prioridad: %2 | Materia: %3 | Fecha: %4")
                                     .arg(realizadas[i].getNombre(),
                                        realizadas[i].getPrioridad(),
                                        realizadas[i].getMateria(),
                                        realizadas[i].getFecha());
        ui->ver_actividades_realizadas->addItem(textoActividad);
    }
}

void actividades_realizadas::on_salir_actividades_realizadas_clicked()
{
    close();
}

