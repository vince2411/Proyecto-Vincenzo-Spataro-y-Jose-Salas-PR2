/********************************************************************************
** Form generated from reading UI file 'actividades_sin_realizar.ui'
**
** Created by: Qt User Interface Compiler version 5.15.13
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ACTIVIDADES_SIN_REALIZAR_H
#define UI_ACTIVIDADES_SIN_REALIZAR_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_actividades_sin_realizar
{
public:
    QLabel *actividades_sin_realizar_titulo;
    QListWidget *actividades_sin_realizar_ver;
    QPushButton *salir_actividades_sin_realizar;

    void setupUi(QDialog *actividades_sin_realizar)
    {
        if (actividades_sin_realizar->objectName().isEmpty())
            actividades_sin_realizar->setObjectName(QString::fromUtf8("actividades_sin_realizar"));
        actividades_sin_realizar->resize(655, 398);
        actividades_sin_realizar->setStyleSheet(QString::fromUtf8("background-color: rgb(94, 92, 100);"));
        actividades_sin_realizar_titulo = new QLabel(actividades_sin_realizar);
        actividades_sin_realizar_titulo->setObjectName(QString::fromUtf8("actividades_sin_realizar_titulo"));
        actividades_sin_realizar_titulo->setGeometry(QRect(180, 0, 261, 41));
        actividades_sin_realizar_titulo->setStyleSheet(QString::fromUtf8("font: 700 16pt \"Ubuntu\";"));
        actividades_sin_realizar_titulo->setAlignment(Qt::AlignmentFlag::AlignCenter);
        actividades_sin_realizar_ver = new QListWidget(actividades_sin_realizar);
        actividades_sin_realizar_ver->setObjectName(QString::fromUtf8("actividades_sin_realizar_ver"));
        actividades_sin_realizar_ver->setGeometry(QRect(50, 50, 551, 251));
        salir_actividades_sin_realizar = new QPushButton(actividades_sin_realizar);
        salir_actividades_sin_realizar->setObjectName(QString::fromUtf8("salir_actividades_sin_realizar"));
        salir_actividades_sin_realizar->setGeometry(QRect(180, 320, 241, 51));
        salir_actividades_sin_realizar->setStyleSheet(QString::fromUtf8("font: 500 14pt \"Ubuntu\";"));

        retranslateUi(actividades_sin_realizar);

        QMetaObject::connectSlotsByName(actividades_sin_realizar);
    } // setupUi

    void retranslateUi(QDialog *actividades_sin_realizar)
    {
        actividades_sin_realizar->setWindowTitle(QCoreApplication::translate("actividades_sin_realizar", "Dialog", nullptr));
        actividades_sin_realizar_titulo->setText(QCoreApplication::translate("actividades_sin_realizar", "Actividades por realizar", nullptr));
        salir_actividades_sin_realizar->setText(QCoreApplication::translate("actividades_sin_realizar", "Salir", nullptr));
    } // retranslateUi

};

namespace Ui {
    class actividades_sin_realizar: public Ui_actividades_sin_realizar {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ACTIVIDADES_SIN_REALIZAR_H
