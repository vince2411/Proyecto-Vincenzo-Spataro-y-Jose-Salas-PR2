/********************************************************************************
** Form generated from reading UI file 'eliminar_actividades.ui'
**
** Created by: Qt User Interface Compiler version 5.15.13
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ELIMINAR_ACTIVIDADES_H
#define UI_ELIMINAR_ACTIVIDADES_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_eliminar_actividades
{
public:
    QLabel *eliminar_titulo;
    QLabel *nombre_eliminar;
    QLabel *materia_eliminar;
    QPushButton *eliminar_Button;
    QTextEdit *recibir_nombre_eliminar;
    QTextEdit *recibir_materia_eliminar;

    void setupUi(QDialog *eliminar_actividades)
    {
        if (eliminar_actividades->objectName().isEmpty())
            eliminar_actividades->setObjectName(QString::fromUtf8("eliminar_actividades"));
        eliminar_actividades->resize(654, 398);
        eliminar_actividades->setStyleSheet(QString::fromUtf8("background-color: rgb(94, 92, 100);"));
        eliminar_titulo = new QLabel(eliminar_actividades);
        eliminar_titulo->setObjectName(QString::fromUtf8("eliminar_titulo"));
        eliminar_titulo->setGeometry(QRect(150, 0, 321, 51));
        eliminar_titulo->setStyleSheet(QString::fromUtf8("font: 700 16pt \"Ubuntu\";"));
        eliminar_titulo->setAlignment(Qt::AlignmentFlag::AlignCenter);
        nombre_eliminar = new QLabel(eliminar_actividades);
        nombre_eliminar->setObjectName(QString::fromUtf8("nombre_eliminar"));
        nombre_eliminar->setGeometry(QRect(50, 100, 111, 31));
        nombre_eliminar->setStyleSheet(QString::fromUtf8("font: 500 14pt \"Ubuntu\";"));
        materia_eliminar = new QLabel(eliminar_actividades);
        materia_eliminar->setObjectName(QString::fromUtf8("materia_eliminar"));
        materia_eliminar->setGeometry(QRect(50, 200, 121, 41));
        materia_eliminar->setStyleSheet(QString::fromUtf8("font: 500 14pt \"Ubuntu\";"));
        eliminar_Button = new QPushButton(eliminar_actividades);
        eliminar_Button->setObjectName(QString::fromUtf8("eliminar_Button"));
        eliminar_Button->setGeometry(QRect(180, 290, 241, 61));
        eliminar_Button->setStyleSheet(QString::fromUtf8("font: 500 14pt \"Ubuntu\";\n"
"background-color: rgb(119, 118, 123);"));
        recibir_nombre_eliminar = new QTextEdit(eliminar_actividades);
        recibir_nombre_eliminar->setObjectName(QString::fromUtf8("recibir_nombre_eliminar"));
        recibir_nombre_eliminar->setGeometry(QRect(170, 100, 361, 41));
        recibir_nombre_eliminar->setOverwriteMode(true);
        recibir_materia_eliminar = new QTextEdit(eliminar_actividades);
        recibir_materia_eliminar->setObjectName(QString::fromUtf8("recibir_materia_eliminar"));
        recibir_materia_eliminar->setGeometry(QRect(170, 200, 361, 41));

        retranslateUi(eliminar_actividades);

        QMetaObject::connectSlotsByName(eliminar_actividades);
    } // setupUi

    void retranslateUi(QDialog *eliminar_actividades)
    {
        eliminar_actividades->setWindowTitle(QCoreApplication::translate("eliminar_actividades", "Dialog", nullptr));
        eliminar_titulo->setText(QCoreApplication::translate("eliminar_actividades", "Eliminar activades", nullptr));
        nombre_eliminar->setText(QCoreApplication::translate("eliminar_actividades", "Nombre", nullptr));
        materia_eliminar->setText(QCoreApplication::translate("eliminar_actividades", "Materia", nullptr));
        eliminar_Button->setText(QCoreApplication::translate("eliminar_actividades", "Eliminar actividad", nullptr));
    } // retranslateUi

};

namespace Ui {
    class eliminar_actividades: public Ui_eliminar_actividades {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ELIMINAR_ACTIVIDADES_H
