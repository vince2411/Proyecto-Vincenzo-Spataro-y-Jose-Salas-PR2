#include "actividades_sin_realizar.h"
#include "ui_actividades_sin_realizar.h"

actividades_sin_realizar::actividades_sin_realizar(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::actividades_sin_realizar)
{
    ui->setupUi(this);
}

actividades_sin_realizar::~actividades_sin_realizar()
{
    delete ui;
}

void actividades_sin_realizar::mostrar_actividades(QVector<Actividad> actividades){
    QVector<Actividad> realizadas;
    for(int i=0; i<actividades.size(); ++i){
        if(actividades[i].getRealizada()==false){
            realizadas.push_back(actividades[i]);
        }
    }
    ui->actividades_sin_realizar_ver->clear();
    for(int i=0; i<realizadas.size(); ++i){
        QString textoActividad = QString("Nombre: %1 | Prioridad: %2 | Materia: %3 | Fecha: %4")
        .arg(realizadas[i].getNombre(),
             realizadas[i].getPrioridad(),
             realizadas[i].getMateria(),
             realizadas[i].getFecha());
        ui->actividades_sin_realizar_ver->addItem(textoActividad);
    }
}

void actividades_sin_realizar::on_salir_actividades_sin_realizar_clicked()
{
    close();
}

