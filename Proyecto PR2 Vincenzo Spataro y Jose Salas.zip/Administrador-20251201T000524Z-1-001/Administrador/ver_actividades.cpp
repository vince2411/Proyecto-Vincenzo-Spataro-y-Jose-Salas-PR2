#include "ver_actividades.h"
#include "ui_ver_actividades.h"

ver_actividades::ver_actividades(QWidget *parent): QDialog(parent), ui(new Ui::ver_actividades)
{
    ui->setupUi(this);
}

void ver_actividades::mostrarActividades(const QVector<Actividad>& lista_actividades)
{
    ui->listWidget_actividades->clear();
    for(int i=0; i<lista_actividades.size(); ++i){
        QString textoActividad = QString("Nombre: %1 | Prioridad: %2 | Materia: %3 | Fecha: %4")
                                         .arg(lista_actividades[i].getNombre(),
                                         lista_actividades[i].getPrioridad(),
                                         lista_actividades[i].getMateria(),
                                         lista_actividades[i].getFecha());
        ui->listWidget_actividades->addItem(textoActividad);
    }
}

ver_actividades::~ver_actividades()
{
    delete ui;
}

void ver_actividades::on_salir_clicked()
{
    close();
}

