#ifndef ACTIVIDADES_SIN_REALIZAR_H
#define ACTIVIDADES_SIN_REALIZAR_H
#include "tareas.h"
#include <QVector>
#include <QDialog>

namespace Ui {
class actividades_sin_realizar;
}

class actividades_sin_realizar : public QDialog
{
    Q_OBJECT

public:
    explicit actividades_sin_realizar(QWidget *parent = nullptr);
    ~actividades_sin_realizar();
    void mostrar_actividades(QVector<Actividad> actividades);

private slots:


    void on_salir_actividades_sin_realizar_clicked();

private:
    Ui::actividades_sin_realizar *ui;
};

#endif 
